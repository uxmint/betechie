package betechie.com;

import java.sql.Connection;
import java.sql.PreparedStatement;



public class EnquiryDAO extends ConnectionProvider{
	
	
	public static int Subscribe(EnquiryBean u){  
		int status=0;  
		try{  
			Connection con=getCon(); 
		PreparedStatement ps=con.prepareStatement("insert into enquiry(E_Email_ID) values(?)");  
		ps.setString(1,u.getE_Email_ID());  
		 
		status=ps.executeUpdate();  
		}catch(Exception e){}  
		      
		return status;  
		} 
	

}
