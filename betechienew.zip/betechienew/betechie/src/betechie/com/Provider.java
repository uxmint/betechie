package betechie.com;
public interface Provider {
	String DRIVER="com.mysql.cj.jdbc.Driver";
	String CONNECTION_URL="jdbc:mysql://localhost:3306/betechie";
	String USERNAME="root";
	String PASSWORD="yippo123";
}
