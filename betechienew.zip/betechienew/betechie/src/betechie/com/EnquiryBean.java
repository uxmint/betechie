package betechie.com;

public class EnquiryBean {
	private String E_Email_ID;
	private String E_Name;
	private String E_IP_Address;
	private String E_Country_Code;
	private String E_Country;
	private String E_State;
	private String E_City;
	private String E_ZIP;
	private String E_Lat;
	private String E_Lan;
	public EnquiryBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public EnquiryBean(String e_Email_ID) {
		super();
		E_Email_ID = e_Email_ID;
	}


	public EnquiryBean(String e_Email_ID, String e_Name, String e_IP_Address, String e_Country_Code, String e_Country,
			String e_State, String e_City, String e_ZIP, String e_Lat, String e_Lan) {
		super();
		E_Email_ID = e_Email_ID;
		E_Name = e_Name;
		E_IP_Address = e_IP_Address;
		E_Country_Code = e_Country_Code;
		E_Country = e_Country;
		E_State = e_State;
		E_City = e_City;
		E_ZIP = e_ZIP;
		E_Lat = e_Lat;
		E_Lan = e_Lan;
	}
	public String getE_Email_ID() {
		return E_Email_ID;
	}
	public void setE_Email_ID(String e_Email_ID) {
		E_Email_ID = e_Email_ID;
	}
	public String getE_Name() {
		return E_Name;
	}
	public void setE_Name(String e_Name) {
		E_Name = e_Name;
	}
	public String getE_IP_Address() {
		return E_IP_Address;
	}
	public void setE_IP_Address(String e_IP_Address) {
		E_IP_Address = e_IP_Address;
	}
	public String getE_Country_Code() {
		return E_Country_Code;
	}
	public void setE_Country_Code(String e_Country_Code) {
		E_Country_Code = e_Country_Code;
	}
	public String getE_Country() {
		return E_Country;
	}
	public void setE_Country(String e_Country) {
		E_Country = e_Country;
	}
	public String getE_State() {
		return E_State;
	}
	public void setE_State(String e_State) {
		E_State = e_State;
	}
	public String getE_City() {
		return E_City;
	}
	public void setE_City(String e_City) {
		E_City = e_City;
	}
	public String getE_ZIP() {
		return E_ZIP;
	}
	public void setE_ZIP(String e_ZIP) {
		E_ZIP = e_ZIP;
	}
	public String getE_Lat() {
		return E_Lat;
	}
	public void setE_Lat(String e_Lat) {
		E_Lat = e_Lat;
	}
	public String getE_Lan() {
		return E_Lan;
	}
	public void setE_Lan(String e_Lan) {
		E_Lan = e_Lan;
	}
	
	
	
	
	
	
	
	
	

}
